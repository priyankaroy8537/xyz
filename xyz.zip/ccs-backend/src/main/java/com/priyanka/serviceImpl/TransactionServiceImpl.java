package com.priyanka.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.priyanka.entity.CreditCard;
import com.priyanka.entity.Merchant;
import com.priyanka.entity.MerchantStatus;
import com.priyanka.entity.Transaction;
import com.priyanka.entity.TransactionType;
import com.priyanka.repository.CreditCardRepository;
import com.priyanka.repository.MerchantRepository;
import com.priyanka.repository.TransactionRepository;
import com.priyanka.service.TransactionService;

import java.util.ArrayList;
import java.util.List;

@Service
public class TransactionServiceImpl implements TransactionService {

    @Autowired
    private TransactionRepository transactionRepository;

    @Autowired
    private CreditCardRepository creditCardRepository;

    @Autowired
    private MerchantRepository merchantRepository;

    @Override
    public Transaction postTransaction(int transactionType, String creditcardNumber, Long merchantID, String currency, String authCode,double transactionAmount) {
        CreditCard creditCard = null;
        Merchant merchant = null;
        

        try {
            // Validate credit card number
            creditCard = creditCardRepository.getByNumber(creditcardNumber);
            if (creditCard == null) {
                throw new IllegalArgumentException("Invalid credit card number");
            }
            if (!creditCard.getCreditcardstatus().equals("open")) {
                throw new IllegalArgumentException("Credit card inactive");
            }

            // Validate merchant code
            merchant = merchantRepository.findById(merchantID)
                .orElseThrow(() -> new IllegalArgumentException("Invalid merchant code"));
            if (!(merchant.getMerchantStatus() == MerchantStatus.ACTIVE)) {
                throw new IllegalArgumentException("Merchant is not available");
            }

            // Handle different transaction types
            switch (transactionType) {
                case 1:
                    // Balance Enquiry: Return the available credit limit and save the transaction
                    Transaction balanceEnquiryTransaction = new Transaction();
                    balanceEnquiryTransaction.setAuthCode(authCode);
                    balanceEnquiryTransaction.setCreditcard(creditCard);
                    balanceEnquiryTransaction.setCurrency(currency);
                    balanceEnquiryTransaction.setMerchant(merchant);
                    balanceEnquiryTransaction.setTransactionAmount(creditCard.getCreditLimit());
                    balanceEnquiryTransaction.setTransactionType(TransactionType.BalanceEnquiry);
                    
                    transactionRepository.save(balanceEnquiryTransaction);
                   // transactions.add(balanceEnquiryTransaction);
                    return balanceEnquiryTransaction;

                case 3:
                    // Purchases: Return all transactions made by this credit card
                	creditCard.setCreditLimit(creditCard.getCreditLimit() + transactionAmount);
                    creditCardRepository.save(creditCard);
                    Transaction paymentsTransaction = new Transaction();
                    paymentsTransaction.setAuthCode(generateAuthCode());
                    paymentsTransaction.setCreditcard(creditCard);
                    paymentsTransaction.setCurrency(currency);
                    paymentsTransaction.setMerchant(merchant);
                    paymentsTransaction.setTransactionAmount(transactionAmount);
                    paymentsTransaction.setTransactionType(TransactionType.Payments);
                    
                    Transaction paymentTransaction = transactionRepository.save(paymentsTransaction);
                    
                    return paymentTransaction;
                   

                case 2:
                    // Payments: Check the credit limit and per day limit, update balances, and create a transaction
                    if (creditCard.getCreditLimit() < transactionAmount) {
                        throw new IllegalArgumentException("Insufficient credit limit");
                    }
                    // Assuming a method exists to check per day limit
                    if (!checkPerDayLimit(creditCard, transactionAmount)) {
                        throw new IllegalArgumentException("Exceeds per day limit");
                    }
                    // Update balances and save the transaction
                    creditCard.setCreditLimit(creditCard.getCreditLimit() - transactionAmount);
                    creditCard.setDailyExpence(creditCard.getDailyExpence()+transactionAmount);
                    creditCardRepository.save(creditCard);
                    Transaction purchaseTransaction = new Transaction();
                    purchaseTransaction.setAuthCode(generateAuthCode());
                    purchaseTransaction.setCreditcard(creditCard);
                    purchaseTransaction.setCurrency(currency);
                    purchaseTransaction.setMerchant(merchant);
                    purchaseTransaction.setTransactionAmount(transactionAmount);
                    purchaseTransaction.setTransactionType(TransactionType.Purchases);
                    
                    Transaction purchasesTransaction = transactionRepository.save(purchaseTransaction);
                    
                    return purchasesTransaction;

                default:
                    throw new IllegalArgumentException("Unsupported transaction type");
            }

        } catch (Exception e) {
            // Create a transaction of type Cancellation in case of any error
            Transaction cancellationTransaction = new Transaction();
            cancellationTransaction.setTransactionType(TransactionType.Cancellation);
            cancellationTransaction.setCreditcard(creditCard);
            cancellationTransaction.setMerchant(merchant);
            cancellationTransaction.setAuthCode(generateAuthCode());
            transactionRepository.save(cancellationTransaction);
           
            throw e;
        }
    }

    private boolean checkPerDayLimit(CreditCard creditCard, double amount) {
        // Implement logic to check per day limit
        // Return true if the amount is within the limit, false otherwise
        double dailyExpense = creditCard.getDailyExpence();
        double limit = creditCard.getProduct().getProductLimit();
        double currentLimit = limit - dailyExpense;
        return amount <= currentLimit;
    }

    private String generateAuthCode() {
        return String.format("%06d", (int) (Math.random() * 1_000_000));
    }
}
