package com.priyanka.service;





import com.priyanka.entity.CreditCard;


public interface CreditCardService {
	public CreditCard getByNumber(String number);
}
