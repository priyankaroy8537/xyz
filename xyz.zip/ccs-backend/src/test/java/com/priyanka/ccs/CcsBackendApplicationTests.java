package com.priyanka.ccs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CcsBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
